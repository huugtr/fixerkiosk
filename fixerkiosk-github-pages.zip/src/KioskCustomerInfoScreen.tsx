import React, { useEffect, useMemo, useState } from "react";
import { Card } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Badge } from "./components/ui/badge";

// ======================================================
// KIOSK FLOW
// 1) Bekleme (günaydın baloncukları + "Ekrana Dokunun" yazısı FR/TR/EN döner)
// 2) Dil Seçim (bayraklı) → tıklayınca direkt anket
// 3) Anket (Ad → Telefon +213 → Email → Konum → Sektör → Ürün)
// 4) Kaydı Tamamla → 5 sn teşekkür → ilk ekrana dön
// + 10 sn etkileşim yoksa otomatik ana ekrana döner
// ======================================================

type Lang = "tr" | "en" | "fr";
type Screen = "idle" | "language" | "survey";
type Sector = "producer" | "contractor" | "showroom";
type ProductGroup = "ERDOOR" | "TICARIMAL" | "DECKER" | "PIPE" | "YARIMAMUL";

type FormState = {
  fullName: string;
  phone: string; // WITHOUT +213, formatted, e.g. "560 00 00 00"
  email: string;
  city: string; // wilaya code
  district: string; // commune name
  sector: Sector | "";
  productGroup: ProductGroup | "";
};

const DEFAULT_FORM: FormState = Object.freeze({
  fullName: "",
  phone: "",
  email: "",
  city: "",
  district: "",
  sector: "",
  productGroup: "",
});

// ================= LOCATION DATA (ALL ALGERIA) =================
// Loaded from "algeria-wilayas" dataset (online)

// Dataset shape can vary by version; support both nested and flat name fields.
type BilingualName = { arabic?: string; ascii?: string };
type WilayaData = {
  code: string | number;
  name?: BilingualName | string;
  name_ascii?: string;
  name_ar?: string;
};

type CommuneData = {
  id: number;
  commune_name: string;
  commune_name_ascii: string;
  daira_name_ascii: string;
  daira_name: string;
  wilaya_code: string;
};

const DZ_DATA_URLS = {
  wilayas: "https://unpkg.com/algeria-wilayas@1.0.1/dist/data/wilayas.json",
  communes: "https://unpkg.com/algeria-wilayas@1.0.1/dist/data/communes.json",
};

const TEXT = {
  tr: {
    tap: "Ekrana Dokunun",
    chooseLang: "Dil Seçin",
    title: "Müşteri Bilgi Formu",
    next: "Devam",
    back: "Geri",
    submit: "Kaydı Tamamla",
    thanks: "Teşekkür Ederiz",
    loadingLoc: "Cezayir şehir/ilçe listesi yükleniyor…",
    offlineNote: "Not: Tablet offline ise konum listesini çekemez. İnternet açık olmalı.",
    cityPick: "Şehir (Wilaya) Seç",
    districtPick: "İlçe (Commune) Seç",
    namePh: "Ad Soyad",
    emailPh: "E-posta",
  },
  en: {
    tap: "Tap to Start",
    chooseLang: "Choose Language",
    title: "Customer Form",
    next: "Next",
    back: "Back",
    submit: "Submit",
    thanks: "Thank you",
    loadingLoc: "Loading locations…",
    offlineNote: "Note: If the tablet is offline, locations cannot load.",
    cityPick: "City (Wilaya)",
    districtPick: "District (Commune)",
    namePh: "Full Name",
    emailPh: "Email",
  },
  fr: {
    tap: "Touchez l'écran",
    chooseLang: "Choisir la langue",
    title: "Formulaire Client",
    next: "Suivant",
    back: "Retour",
    submit: "Valider",
    thanks: "Merci",
    loadingLoc: "Chargement des wilayas/communes…",
    offlineNote: "Note: Sans internet, la liste ne peut pas être chargée.",
    cityPick: "Wilaya",
    districtPick: "Commune",
    namePh: "Nom Prénom",
    emailPh: "E-mail",
  },
} as const;

type Step = "name" | "phone" | "email" | "location" | "sector" | "product";
const STEPS: Step[] = ["name", "phone", "email", "location", "sector", "product"];

// ================= HELPERS =================
function formatDzPhone(input: string): string {
  // Keep only digits, max 9 digits (Algeria mobile without country code)
  const digits = String(input || "").replace(/[^0-9]/g, "").slice(0, 9);
  const p1 = digits.slice(0, 3);
  const p2 = digits.slice(3, 5);
  const p3 = digits.slice(5, 7);
  const p4 = digits.slice(7, 9);
  return [p1, p2, p3, p4].filter(Boolean).join(" ");
}

function getWilayaLabel(w: WilayaData): string {
  const code = String(w.code);
  return (
    (typeof w.name === "object" ? w.name?.ascii : undefined) ||
    (typeof w.name === "string" ? w.name : undefined) ||
    w.name_ascii ||
    w.name_ar ||
    code
  );
}

export default function KioskCustomerInfoScreen() {
  const [screen, setScreen] = useState<Screen>("idle");
  const [lang, setLang] = useState<Lang>("tr");
  const [stepIndex, setStepIndex] = useState(0);
  const [form, setForm] = useState<FormState>({ ...DEFAULT_FORM });
  const [submitted, setSubmitted] = useState(false);
  const [countdown, setCountdown] = useState<number | null>(null);

  // Inactivity auto-reset (10s without interaction → go to idle)
  const INACTIVITY_MS = 10000;
  const [lastActivity, setLastActivity] = useState<number>(Date.now());

  // Algeria locations
  const [wilayas, setWilayas] = useState<WilayaData[]>([]);
  const [communesByWilaya, setCommunesByWilaya] = useState<Record<string, string[]>>({});
  const [locLoading, setLocLoading] = useState(true);
  const [locError, setLocError] = useState<string | null>(null);

  const wilayaLabelByCode = useMemo(() => {
    const m: Record<string, string> = {};
    for (const w of wilayas) m[String(w.code)] = getWilayaLabel(w);
    return m;
  }, [wilayas]);

  useEffect(() => {
    let cancelled = false;

    async function loadDzLocations() {
      try {
        setLocLoading(true);
        setLocError(null);

        const [wilRes, comRes] = await Promise.all([
          fetch(DZ_DATA_URLS.wilayas),
          fetch(DZ_DATA_URLS.communes),
        ]);

        if (!wilRes.ok) throw new Error(`Wilayas yüklenemedi (${wilRes.status})`);
        if (!comRes.ok) throw new Error(`Communes yüklenemedi (${comRes.status})`);

        const wilJson = (await wilRes.json()) as WilayaData[];
        const comJson = (await comRes.json()) as CommuneData[];

        const map: Record<string, string[]> = {};
        for (const c of comJson) {
          const key = String(c.wilaya_code);
          const name = c.commune_name_ascii || c.commune_name;
          if (!map[key]) map[key] = [];
          map[key].push(name);
        }

        for (const k of Object.keys(map)) {
          map[k] = Array.from(new Set(map[k])).sort((a, b) => a.localeCompare(b));
        }

        wilJson.sort((a, b) => getWilayaLabel(a).localeCompare(getWilayaLabel(b)));

        if (cancelled) return;
        setWilayas(wilJson);
        setCommunesByWilaya(map);
      } catch (e: any) {
        if (cancelled) return;
        setLocError(e?.message || "Konum listesi yüklenemedi");
      } finally {
        if (!cancelled) setLocLoading(false);
      }
    }

    loadDzLocations();
    return () => {
      cancelled = true;
    };
  }, []);

  const step = STEPS[stepIndex];

  // Track user activity (only outside idle screen)
  useEffect(() => {
    if (screen === "idle") return;

    const updateActivity = () => setLastActivity(Date.now());
    window.addEventListener("click", updateActivity);
    window.addEventListener("touchstart", updateActivity);
    window.addEventListener("keydown", updateActivity);

    return () => {
      window.removeEventListener("click", updateActivity);
      window.removeEventListener("touchstart", updateActivity);
      window.removeEventListener("keydown", updateActivity);
    };
  }, [screen]);

  // Auto reset if inactive
  useEffect(() => {
    if (screen === "idle") return;

    const interval = window.setInterval(() => {
      if (Date.now() - lastActivity > INACTIVITY_MS) {
        setForm({ ...DEFAULT_FORM });
        setSubmitted(false);
        setCountdown(null);
        setStepIndex(0);
        setScreen("idle");
      }
    }, 1000);

    return () => window.clearInterval(interval);
  }, [lastActivity, screen]);

  // Background greeting bubbles
  const greetings = useMemo(
    () => [
      "Günaydın",
      "Good morning",
      "Bonjour",
      "صباح الخير",
      "Buenos días",
      "Guten Morgen",
      "Buongiorno",
      "Bom dia",
      "Доброе утро",
      "おはよう",
      "早上好",
      "Goedemorgen",
      "God morgon",
      "Καλημέρα",
      "Dzień dobry",
    ],
    []
  );

  // Keep bubbles away from center where the "Tap" card sits.
  const bubbles = useMemo(
    () =>
      Array.from({ length: 26 }).map((_, i) => {
        const text = greetings[Math.floor(Math.random() * greetings.length)];
        const isRed = Math.random() > 0.45;

        let left = 0;
        let top = 0;
        let tries = 0;
        do {
          left = Math.random() * 92 + 4; // 4% – 96%
          top = Math.random() * 78 + 8; // 8% – 86%
          tries++;
        } while (left > 30 && left < 70 && top > 30 && top < 70 && tries < 20);

        return {
          id: i,
          left,
          top,
          delay: Math.random() * 6,
          duration: 4.5 + Math.random() * 3.5,
          isRed,
          text,
          scale: 0.7 + Math.random() * 0.25,
        };
      }),
    [greetings]
  );

  // Idle screen: rotate "Tap" text FR → TR → EN
  const idlePhrases = useMemo(() => [TEXT.fr.tap, TEXT.tr.tap, TEXT.en.tap], []);
  const [idlePhraseIdx, setIdlePhraseIdx] = useState(0);

  useEffect(() => {
    if (screen !== "idle") return;
    const tmr = window.setInterval(() => {
      setIdlePhraseIdx((idx) => (idx + 1) % idlePhrases.length);
    }, 2200);
    return () => window.clearInterval(tmr);
  }, [screen, idlePhrases.length]);

  // Countdown after submit
  useEffect(() => {
    if (countdown === null) return;
    if (countdown === 0) {
      setForm({ ...DEFAULT_FORM });
      setSubmitted(false);
      setCountdown(null);
      setStepIndex(0);
      setScreen("idle");
      return;
    }
    const timer = window.setTimeout(() => {
      setCountdown((c) => (typeof c === "number" ? c - 1 : null));
    }, 1000);
    return () => window.clearTimeout(timer);
  }, [countdown]);

  // ================= SCREENS =================
  if (screen === "idle") {
    return (
      <div
        className="relative min-h-screen overflow-hidden bg-gradient-to-b from-blue-100 to-white flex items-center justify-center"
        onClick={() => setScreen("language")}
      >
        <style>{`
          @keyframes popFade {
            0% { transform: translateY(6px) scale(var(--s)); opacity: 0; }
            15% { opacity: 0.75; }
            50% { opacity: 0.75; transform: translateY(0px) scale(var(--s)); }
            85% { opacity: 0.75; }
            100% { transform: translateY(-6px) scale(var(--s)); opacity: 0; }
          }
        `}</style>

        {bubbles.map((b) => (
          <div
            key={b.id}
            className={
              "absolute rounded-2xl px-3 py-2 shadow-md backdrop-blur-md border select-none " +
              (b.isRed
                ? "bg-[#C8102E]/75 text-white border-[#C8102E]/30"
                : "bg-gray-200/75 text-gray-900 border-white/60")
            }
            style={{
              left: `${b.left}%`,
              top: `${b.top}%`,
              animationName: "popFade",
              animationDuration: `${b.duration}s`,
              animationDelay: `${b.delay}s`,
              animationTimingFunction: "ease-in-out",
              animationIterationCount: "infinite",
              // @ts-ignore CSS variable
              "--s": b.scale,
              transformOrigin: "left bottom",
              maxWidth: "200px",
            }}
          >
            <span className="text-sm md:text-base leading-tight">{b.text}</span>
          </div>
        ))}

        <div className="z-10 px-10 py-6 rounded-3xl bg-[#C8102E]/85 backdrop-blur-xl shadow-2xl border border-[#C8102E]/40">
          <div className="text-3xl md:text-4xl font-bold text-white animate-pulse tracking-wide">
            {idlePhrases[idlePhraseIdx]}
          </div>
        </div>
      </div>
    );
  }

  if (screen === "language") {
    const goSurvey = (l: Lang) => {
      setLang(l);
      setForm({ ...DEFAULT_FORM });
      setSubmitted(false);
      setCountdown(null);
      setStepIndex(0);
      setScreen("survey");
    };

    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-6 bg-gray-50">
        <div className="text-3xl font-semibold">{TEXT[lang].chooseLang}</div>

        <div className="grid grid-cols-3 gap-6">
          <Button
            onClick={() => goSurvey("tr")}
            className="flex flex-col items-center gap-3 h-28 text-lg rounded-2xl"
          >
            <img
              src="https://flagcdn.com/w80/tr.png"
              alt="Türkçe"
              className="w-12 h-8 object-cover rounded shadow"
            />
            <span>Türkçe</span>
          </Button>

          <Button
            onClick={() => goSurvey("en")}
            className="flex flex-col items-center gap-3 h-28 text-lg rounded-2xl"
          >
            <img
              src="https://flagcdn.com/w80/gb.png"
              alt="English"
              className="w-12 h-8 object-cover rounded shadow"
            />
            <span>English</span>
          </Button>

          <Button
            onClick={() => goSurvey("fr")}
            className="flex flex-col items-center gap-3 h-28 text-lg rounded-2xl"
          >
            <img
              src="https://flagcdn.com/w80/fr.png"
              alt="Français"
              className="w-12 h-8 object-cover rounded shadow"
            />
            <span>Français</span>
          </Button>
        </div>
      </div>
    );
  }

  // ================= SURVEY =================
  const setField = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  function next() {
    if (stepIndex < STEPS.length - 1) {
      setStepIndex((s) => s + 1);
      return;
    }
    setSubmitted(true);
    setCountdown(5);
  }

  function back() {
    if (stepIndex === 0) {
      setScreen("language");
      return;
    }
    setStepIndex((s) => Math.max(0, s - 1));
  }

  const sectorLabelMap = {
    producer: { tr: "ÜRETİCİ", en: "PRODUCER", fr: "PRODUCTEUR" },
    contractor: { tr: "İNŞAATÇI", en: "CONTRACTOR", fr: "ENTREPRENEUR" },
    showroom: { tr: "SHOWROOM", en: "SHOWROOM", fr: "SHOWROOM" },
  } as const;

  return (
    <div className="min-h-screen p-8 bg-white space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">{TEXT[lang].title}</h1>
        <Badge>
          {stepIndex + 1}/{STEPS.length}
        </Badge>
      </div>

      {!submitted && (
        <Card className="p-8 space-y-6">
          {step === "name" && (
            <input
              className="w-full h-14 border rounded-xl px-4"
              placeholder={TEXT[lang].namePh}
              value={form.fullName}
              onChange={(e) => setField("fullName", e.target.value)}
            />
          )}

          {step === "phone" && (
            <div className="space-y-2">
              <div className="flex items-center border rounded-xl h-14 overflow-hidden bg-white">
                <div className="h-full px-4 flex items-center bg-gray-100 text-gray-700 font-semibold select-none">
                  +213
                </div>
                <input
                  className="flex-1 h-full px-4 outline-none"
                  placeholder="560 00 00 00"
                  inputMode="tel"
                  autoComplete="tel"
                  value={form.phone ?? ""}
                  onChange={(e) => setField("phone", formatDzPhone(e.target.value))}
                />
              </div>
              <div className="text-xs text-gray-500">Format: +213 560 00 00 00</div>
            </div>
          )}

          {step === "email" && (
            <input
              className="w-full h-14 border rounded-xl px-4"
              placeholder={TEXT[lang].emailPh}
              value={form.email}
              onChange={(e) => setField("email", e.target.value)}
            />
          )}

          {step === "location" && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <select
                  className="h-14 border rounded-xl px-4"
                  value={form.city}
                  onChange={(e) => {
                    const city = e.target.value;
                    setForm((prev) => ({ ...prev, city, district: "" }));
                  }}
                  disabled={locLoading}
                >
                  <option value="">{TEXT[lang].cityPick}</option>
                  {wilayas.map((w) => {
                    const code = String(w.code);
                    const label = wilayaLabelByCode[code] || code;
                    return (
                      <option key={code} value={code}>
                        {label}
                      </option>
                    );
                  })}
                </select>

                <select
                  className="h-14 border rounded-xl px-4"
                  value={form.district}
                  onChange={(e) => setField("district", e.target.value)}
                  disabled={!form.city || locLoading}
                >
                  <option value="">{TEXT[lang].districtPick}</option>
                  {form.city && (communesByWilaya[form.city] || []).map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              {locLoading && <div className="text-sm text-gray-500">{TEXT[lang].loadingLoc}</div>}

              {locError && (
                <div className="text-sm text-red-600">
                  {locError}
                  <div className="text-xs text-gray-500 mt-1">{TEXT[lang].offlineNote}</div>
                </div>
              )}
            </div>
          )}

          {step === "sector" && (
            <div className="grid grid-cols-3 gap-3">
              {(["producer", "contractor", "showroom"] as const).map((s) => (
                <Button
                  key={s}
                  variant={form.sector === s ? "default" : "outline"}
                  onClick={() => setField("sector", s)}
                >
                  {sectorLabelMap[s][lang]}
                </Button>
              ))}
            </div>
          )}

          {step === "product" && (
            <div className="grid grid-cols-3 gap-3">
              {(["ERDOOR", "TICARIMAL", "DECKER", "PIPE", "YARIMAMUL"] as const).map((p) => (
                <Button
                  key={p}
                  variant={form.productGroup === p ? "default" : "outline"}
                  onClick={() => setField("productGroup", p)}
                >
                  {p}
                </Button>
              ))}
            </div>
          )}

          <div className="flex justify-end gap-4 pt-6">
            <Button onClick={back} className="h-12 px-6">
              {TEXT[lang].back}
            </Button>
            <Button onClick={next} className="h-12 px-6">
              {stepIndex < STEPS.length - 1 ? TEXT[lang].next : TEXT[lang].submit}
            </Button>
          </div>
        </Card>
      )}

      {submitted && (
        <Card className="p-10 space-y-4 text-center">
          <div className="text-3xl font-bold text-[#C8102E]">
            {TEXT[lang].thanks}
            {typeof countdown === "number" ? ` (${countdown})` : ""}
          </div>
          <div className="text-gray-500 text-lg">
            {typeof countdown === "number"
              ? lang === "tr"
                ? `${countdown} saniye sonra ana ekrana dönülecek...`
                : lang === "fr"
                ? `Retour à l'accueil dans ${countdown} s...`
                : `Returning to home in ${countdown}s...`
              : ""}
          </div>
        </Card>
      )}
    </div>
  );
}

// ================= \"TESTS\" (lightweight runtime checks) =================
// These checks help catch regressions during development.
function __devTests() {
  try {
    console.assert(formatDzPhone("560000000") === "560 00 00 00", "Phone formatting failed");
    console.assert(formatDzPhone("560 00 00 00") === "560 00 00 00", "Phone formatting idempotency failed");
    console.assert(
      formatDzPhone("+213 560-00-00-00") === "213 56 00 00",
      "Phone formatting sanitization check"
    );
  } catch {
    // no-op
  }
}

// Run tests in browser-like environments
// @ts-ignore
if (typeof window !== "undefined") __devTests();
