# fixerkiosk (GitHub Pages)

Bu repo **GitHub Pages** için hazırdır (Vite `base: '/fixerkiosk/'` ayarlı).

## Local
```bash
npm install
npm run dev
```

## GitHub Pages (otomatik)
1. GitHub'a pushla (branch: `main`)
2. GitHub → Settings → Pages → Source: **GitHub Actions**
3. Workflow çalışınca link şu olur:
   `https://<username>.github.io/fixerkiosk/`
